from flask import Flask, render_template, request, jsonify
import joblib
import os
import sys

# Add the current directory to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from model.personality_model import PersonalityPredictor

app = Flask(__name__)

# Global variables for model and preprocessor
model = None
preprocessor = None

def load_models():
    """Load trained model and preprocessor"""
    global model, preprocessor
    
    model_path = 'saved_models/personality_model.pkl'
    preprocessor_path = 'saved_models/preprocessor.pkl'
    
    if os.path.exists(model_path) and os.path.exists(preprocessor_path):
        try:
            model = PersonalityPredictor()
            model.load_model(model_path)
            
            # Load preprocessor with proper path handling
            sys.path.append('model')
            preprocessor = joblib.load(preprocessor_path)
            
            print("Models loaded successfully!")
            return True
        except Exception as e:
            print(f"Error loading models: {e}")
            return False
    else:
        print("Model files not found. Please train the model first.")
        return False

@app.route('/')
def index():
    """Main page"""
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict_personality():
    """Predict personality traits from text"""
    try:
        # Get text from request
        data = request.get_json()
        text = data.get('text', '').strip()
        
        if not text:
            return jsonify({'error': 'No text provided'}), 400
        
        if len(text) < 10:
            return jsonify({'error': 'Text too short. Please provide at least 10 characters.'}), 400
        
        # Check if models are loaded
        if model is None or preprocessor is None:
            if not load_models():
                return jsonify({'error': 'Models not available. Please train the model first.'}), 500
        
        # Preprocess and predict
        X = preprocessor.transform_text([text])
        predictions = model.predict_single(X)
        
        # Generate interpretation
        interpretation = model.get_interpretation(predictions)
        
        # Prepare response
        response = {
            'predictions': predictions,
            'interpretation': interpretation,
            'success': True
        }
        
        return jsonify(response)
    
    except Exception as e:
        print(f"Prediction error: {e}")
        return jsonify({'error': f'Prediction failed: {str(e)}'}), 500

@app.route('/health')
def health_check():
    """Health check endpoint"""
    models_loaded = model is not None and preprocessor is not None
    return jsonify({
        'status': 'healthy' if models_loaded else 'models_not_loaded',
        'models_loaded': models_loaded
    })

if __name__ == '__main__':
    # Try to load models on startup
    load_models()
    
    # Run the app
    app.run(debug=True, host='0.0.0.0', port=5000)