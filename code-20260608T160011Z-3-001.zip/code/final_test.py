#!/usr/bin/env python3
"""
Final comprehensive test of the AI Personality Prediction System
"""

import requests
import json
import time
import threading
from app import app

def test_api():
    """Test the API endpoints"""
    print("🌐 Testing API endpoints...")
    
    # Test data
    test_text = "I love exploring new ideas and creative projects. Art and philosophy fascinate me deeply. I'm always curious about different cultures and unconventional approaches to life."
    
    try:
        # Test prediction endpoint
        response = requests.post('http://localhost:5000/predict', 
                               json={'text': test_text},
                               timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            print("✅ Prediction API working!")
            print(f"Sample prediction: {list(data['predictions'].keys())}")
            return True
        else:
            print(f"❌ API returned status {response.status_code}")
            return False
            
    except requests.exceptions.ConnectionError:
        print("❌ Could not connect to server")
        return False
    except Exception as e:
        print(f"❌ API test failed: {e}")
        return False

def run_server():
    """Run the Flask server in a separate thread"""
    app.run(debug=False, host='localhost', port=5000, use_reloader=False)

def main():
    print("🚀 Final System Test - AI Personality Prediction")
    print("=" * 60)
    
    # Start server in background
    print("🔄 Starting Flask server...")
    server_thread = threading.Thread(target=run_server, daemon=True)
    server_thread.start()
    
    # Wait for server to start
    time.sleep(3)
    
    # Test API
    api_success = test_api()
    
    if api_success:
        print("\n🎉 SYSTEM TEST PASSED!")
        print("\n📋 Your AI Personality Prediction System is ready!")
        print("🌐 Access it at: http://localhost:5000")
        print("\n💡 Features available:")
        print("  • Text analysis and personality prediction")
        print("  • Interactive web interface")
        print("  • Real-time visualization")
        print("  • Sample texts to try")
        print("\n🔧 To run manually: python app.py")
    else:
        print("\n❌ SYSTEM TEST FAILED!")
        print("Please check the error messages above.")
    
    return api_success

if __name__ == "__main__":
    success = main()
    if success:
        print("\nPress Ctrl+C to stop the server and exit.")
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n👋 Goodbye!")
    else:
        exit(1)