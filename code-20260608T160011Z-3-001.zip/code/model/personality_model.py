import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.multioutput import MultiOutputRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
import joblib
import os

class PersonalityPredictor:
    def __init__(self):
        self.model = MultiOutputRegressor(RandomForestRegressor(n_estimators=50, random_state=42, max_depth=10))
        self.trait_names = ['Openness', 'Conscientiousness', 'Extraversion', 'Agreeableness', 'Neuroticism']
        self.is_trained = False
    
    def train(self, X_train, y_train, X_test=None, y_test=None):
        """Train the personality prediction model"""
        print("Training personality prediction model...")
        
        # Train the model
        self.model.fit(X_train, y_train)
        self.is_trained = True
        
        # Evaluate if test data provided
        if X_test is not None and y_test is not None:
            y_pred = self.model.predict(X_test)
            mse = mean_squared_error(y_test, y_pred)
            r2 = r2_score(y_test, y_pred)
            
            print(f"Model Performance:")
            print(f"Mean Squared Error: {mse:.4f}")
            print(f"R² Score: {r2:.4f}")
            
            # Individual trait performance
            for i, trait in enumerate(self.trait_names):
                trait_r2 = r2_score(y_test[:, i], y_pred[:, i])
                print(f"{trait} R²: {trait_r2:.4f}")
        
        return self.model
    
    def predict(self, X):
        """Predict personality traits"""
        if not self.is_trained:
            raise ValueError("Model must be trained before making predictions")
        
        predictions = self.model.predict(X)
        
        # Ensure predictions are in [0, 1] range
        predictions = np.clip(predictions, 0, 1)
        
        return predictions
    
    def predict_single(self, X):
        """Predict personality traits for a single sample"""
        predictions = self.predict(X)
        
        if len(predictions.shape) > 1 and predictions.shape[0] == 1:
            predictions = predictions[0]
        
        # Create result dictionary
        result = {}
        for i, trait in enumerate(self.trait_names):
            score = float(predictions[i])
            result[trait] = {
                'score': score,
                'percentage': round(score * 100, 1),
                'level': self._get_trait_level(score)
            }
        
        return result
    
    def _get_trait_level(self, score):
        """Convert score to descriptive level"""
        if score >= 0.7:
            return "High"
        elif score >= 0.4:
            return "Moderate"
        else:
            return "Low"
    
    def save_model(self, filepath):
        """Save trained model"""
        if not self.is_trained:
            raise ValueError("Cannot save untrained model")
        
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        joblib.dump(self.model, filepath)
        print(f"Model saved to {filepath}")
    
    def load_model(self, filepath):
        """Load trained model"""
        if os.path.exists(filepath):
            self.model = joblib.load(filepath)
            self.is_trained = True
            print(f"Model loaded from {filepath}")
            return True
        else:
            print(f"Model file not found: {filepath}")
            return False
    
    def get_interpretation(self, predictions):
        """Generate human-readable interpretation"""
        interpretations = []
        
        for trait, data in predictions.items():
            level = data['level']
            percentage = data['percentage']
            
            if trait == 'Openness':
                if level == 'High':
                    interpretations.append(f"highly creative and open to new experiences ({percentage}%)")
                elif level == 'Moderate':
                    interpretations.append(f"moderately open to new ideas ({percentage}%)")
                else:
                    interpretations.append(f"prefers routine and familiar experiences ({percentage}%)")
            
            elif trait == 'Conscientiousness':
                if level == 'High':
                    interpretations.append(f"very organized and disciplined ({percentage}%)")
                elif level == 'Moderate':
                    interpretations.append(f"reasonably organized ({percentage}%)")
                else:
                    interpretations.append(f"more spontaneous and flexible ({percentage}%)")
            
            elif trait == 'Extraversion':
                if level == 'High':
                    interpretations.append(f"highly social and energetic ({percentage}%)")
                elif level == 'Moderate':
                    interpretations.append(f"balanced between social and solitary activities ({percentage}%)")
                else:
                    interpretations.append(f"prefers quiet and solitary activities ({percentage}%)")
            
            elif trait == 'Agreeableness':
                if level == 'High':
                    interpretations.append(f"very cooperative and trusting ({percentage}%)")
                elif level == 'Moderate':
                    interpretations.append(f"generally cooperative ({percentage}%)")
                else:
                    interpretations.append(f"more competitive and skeptical ({percentage}%)")
            
            elif trait == 'Neuroticism':
                if level == 'High':
                    interpretations.append(f"tends to experience emotional instability ({percentage}%)")
                elif level == 'Moderate':
                    interpretations.append(f"generally emotionally stable ({percentage}%)")
                else:
                    interpretations.append(f"very emotionally stable and calm ({percentage}%)")
        
        return "This person appears " + ", ".join(interpretations) + "."