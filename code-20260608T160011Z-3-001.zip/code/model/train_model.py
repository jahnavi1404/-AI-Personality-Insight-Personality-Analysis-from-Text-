import pandas as pd
import numpy as np
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from sklearn.model_selection import train_test_split
from preprocessor import TextPreprocessor
from personality_model import PersonalityPredictor
import joblib

def create_synthetic_dataset():
    """Create a synthetic dataset for training"""
    print("Creating synthetic training dataset...")
    
    # Sample texts with different personality indicators
    high_openness_texts = [
        "I love exploring new ideas and creative projects. Art and philosophy fascinate me.",
        "Always curious about different cultures and unconventional approaches to life.",
        "I enjoy abstract thinking and imagining possibilities that don't exist yet.",
        "Reading poetry and experimental literature is my passion.",
        "I'm drawn to innovative solutions and thinking outside the box."
    ]
    
    high_conscientiousness_texts = [
        "I always plan my day carefully and stick to my schedule.",
        "Organization and attention to detail are crucial for success.",
        "I believe in hard work and completing tasks thoroughly.",
        "Setting goals and achieving them systematically is important to me.",
        "I prefer structured environments and clear expectations."
    ]
    
    high_extraversion_texts = [
        "I love meeting new people and being the center of attention!",
        "Parties and social gatherings energize me so much.",
        "I'm always talking and sharing my thoughts with others.",
        "Group activities and teamwork are the best parts of any project.",
        "I feel most alive when I'm around lots of people."
    ]
    
    high_agreeableness_texts = [
        "I always try to help others and avoid conflicts.",
        "Cooperation and harmony are more important than winning.",
        "I trust people and believe in their good intentions.",
        "Making others happy brings me joy and satisfaction.",
        "I prefer to compromise rather than argue."
    ]
    
    high_neuroticism_texts = [
        "I often worry about things that might go wrong.",
        "Stress and anxiety affect me more than most people.",
        "I tend to overthink situations and feel overwhelmed easily.",
        "My mood changes frequently throughout the day.",
        "I'm sensitive to criticism and take things personally."
    ]
    
    # Create balanced dataset
    texts = []
    labels = []
    
    # Generate combinations of traits
    for _ in range(200):
        # Random combination of high/low traits
        openness = np.random.choice([0.2, 0.8])
        conscientiousness = np.random.choice([0.2, 0.8])
        extraversion = np.random.choice([0.2, 0.8])
        agreeableness = np.random.choice([0.2, 0.8])
        neuroticism = np.random.choice([0.2, 0.8])
        
        # Select text based on dominant trait
        dominant_trait = np.argmax([openness, conscientiousness, extraversion, agreeableness, neuroticism])
        
        if dominant_trait == 0:  # Openness
            text = np.random.choice(high_openness_texts)
        elif dominant_trait == 1:  # Conscientiousness
            text = np.random.choice(high_conscientiousness_texts)
        elif dominant_trait == 2:  # Extraversion
            text = np.random.choice(high_extraversion_texts)
        elif dominant_trait == 3:  # Agreeableness
            text = np.random.choice(high_agreeableness_texts)
        else:  # Neuroticism
            text = np.random.choice(high_neuroticism_texts)
        
        # Add some noise to make it more realistic
        openness += np.random.normal(0, 0.1)
        conscientiousness += np.random.normal(0, 0.1)
        extraversion += np.random.normal(0, 0.1)
        agreeableness += np.random.normal(0, 0.1)
        neuroticism += np.random.normal(0, 0.1)
        
        # Clip to [0, 1] range
        traits = np.clip([openness, conscientiousness, extraversion, agreeableness, neuroticism], 0, 1)
        
        texts.append(text)
        labels.append(traits)
    
    return texts, np.array(labels)

def train_personality_model():
    """Train the personality prediction model"""
    # Create synthetic dataset
    texts, labels = create_synthetic_dataset()
    
    # Initialize preprocessor
    preprocessor = TextPreprocessor()
    
    # Preprocess texts and fit vectorizer
    print("Preprocessing texts...")
    processed_texts = preprocessor.fit_vectorizer(texts)
    X = preprocessor.vectorizer.transform(processed_texts)
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, labels, test_size=0.2, random_state=42
    )
    
    # Initialize and train model
    model = PersonalityPredictor()
    model.train(X_train, y_train, X_test, y_test)
    
    # Save model and preprocessor
    os.makedirs('saved_models', exist_ok=True)
    model.save_model('saved_models/personality_model.pkl')
    joblib.dump(preprocessor, 'saved_models/preprocessor.pkl')
    
    print("Training completed successfully!")
    print("Model and preprocessor saved to 'saved_models/' directory")
    
    return model, preprocessor

if __name__ == "__main__":
    train_personality_model()