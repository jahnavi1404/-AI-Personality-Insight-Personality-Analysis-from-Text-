#!/usr/bin/env python3
"""
Setup script for AI Personality Prediction System
This script will install dependencies and train the model
"""

import subprocess
import sys
import os

def run_command(command, description):
    """Run a command and handle errors"""
    print(f"\n🔄 {description}...")
    try:
        result = subprocess.run(command, shell=True, check=True, capture_output=True, text=True)
        print(f"✅ {description} completed successfully!")
        if result.stdout.strip():
            print(f"Output: {result.stdout.strip()}")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ {description} failed!")
        print(f"Error: {e.stderr}")
        return False

def check_models_exist():
    """Check if trained models already exist"""
    return (os.path.exists('saved_models/personality_model.pkl') and 
            os.path.exists('saved_models/preprocessor.pkl'))

def main():
    print("🚀 Setting up AI Personality Prediction System")
    print("=" * 50)
    
    # Check Python version
    if sys.version_info < (3, 7):
        print("❌ Python 3.7 or higher is required!")
        sys.exit(1)
    
    print(f"✅ Python {sys.version.split()[0]} detected")
    
    # Install dependencies
    print("\n📦 Installing dependencies...")
    if not run_command("pip install -r requirements.txt", "Installing Python packages"):
        print("\n💡 Alternative: Try 'python -m pip install -r requirements.txt'")
        return False
    
    # Check if models already exist
    if check_models_exist():
        print("\n✅ Trained models found! Skipping training.")
    else:
        # Train the model
        if not run_command("python model/train_model.py", "Training the personality prediction model"):
            return False
    
    print("\n🎉 Setup completed successfully!")
    print("\n📋 Next steps:")
    print("1. Run: python app.py")
    print("2. Open: http://localhost:5000")
    print("3. Enter text and analyze personality!")
    print("\n🧪 Or run the test: python final_test.py")
    
    return True

if __name__ == "__main__":
    success = main()
    if not success:
        sys.exit(1)