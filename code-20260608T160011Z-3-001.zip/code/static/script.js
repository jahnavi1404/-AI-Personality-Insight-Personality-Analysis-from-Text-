// Sample texts for demonstration
const sampleTexts = [
    "I love exploring new ideas and creative projects. Art and philosophy fascinate me deeply. I'm always curious about different cultures and unconventional approaches to life. I enjoy abstract thinking and imagining possibilities that don't exist yet. Reading experimental literature and discovering new perspectives brings me joy.",
    
    "I always plan my day carefully and stick to my schedule religiously. Organization and attention to detail are crucial for my success. I believe in hard work and completing every task thoroughly and on time. Setting clear goals and achieving them systematically is very important to me. I prefer structured environments with clear expectations.",
    
    "I absolutely love meeting new people and being around others! Parties and social gatherings energize me so much. I'm always talking and sharing my thoughts with friends and strangers alike. Group activities and teamwork are definitely the best parts of any project. I feel most alive when I'm surrounded by lots of people and conversation."
];

let personalityChart = null;

function loadSample(index) {
    const textInput = document.getElementById('textInput');
    textInput.value = sampleTexts[index];
    textInput.focus();
}

function clearText() {
    document.getElementById('textInput').value = '';
    document.getElementById('results').style.display = 'none';
    if (personalityChart) {
        personalityChart.destroy();
        personalityChart = null;
    }
}

async function analyzePersonality() {
    const textInput = document.getElementById('textInput');
    const text = textInput.value.trim();
    
    // Validation
    if (!text) {
        alert('Please enter some text to analyze.');
        return;
    }
    
    if (text.length < 10) {
        alert('Please provide at least 10 characters of text.');
        return;
    }
    
    // Show loading state
    const analyzeBtn = document.getElementById('analyzeBtn');
    const btnText = document.getElementById('btnText');
    const loadingSpinner = document.getElementById('loadingSpinner');
    
    analyzeBtn.disabled = true;
    btnText.style.display = 'none';
    loadingSpinner.style.display = 'inline';
    
    try {
        // Make API call
        const response = await fetch('/predict', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ text: text })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || 'Prediction failed');
        }
        
        // Display results
        displayResults(data.predictions, data.interpretation);
        
    } catch (error) {
        console.error('Error:', error);
        alert('Error analyzing personality: ' + error.message);
    } finally {
        // Reset button state
        analyzeBtn.disabled = false;
        btnText.style.display = 'inline';
        loadingSpinner.style.display = 'none';
    }
}

function displayResults(predictions, interpretation) {
    // Show results section
    document.getElementById('results').style.display = 'block';
    
    // Display interpretation
    document.getElementById('interpretation').innerHTML = interpretation;
    
    // Prepare data for chart
    const traits = Object.keys(predictions);
    const scores = traits.map(trait => predictions[trait].percentage);
    const colors = [
        '#FF6384', // Openness - Pink
        '#36A2EB', // Conscientiousness - Blue
        '#FFCE56', // Extraversion - Yellow
        '#4BC0C0', // Agreeableness - Teal
        '#9966FF'  // Neuroticism - Purple
    ];
    
    // Create chart
    createPersonalityChart(traits, scores, colors);
    
    // Display trait details
    displayTraitDetails(predictions);
    
    // Scroll to results
    document.getElementById('results').scrollIntoView({ 
        behavior: 'smooth',
        block: 'start'
    });
}

function createPersonalityChart(traits, scores, colors) {
    const ctx = document.getElementById('personalityChart').getContext('2d');
    
    // Destroy existing chart if it exists
    if (personalityChart) {
        personalityChart.destroy();
    }
    
    personalityChart = new Chart(ctx, {
        type: 'radar',
        data: {
            labels: traits,
            datasets: [{
                label: 'Personality Traits',
                data: scores,
                backgroundColor: 'rgba(102, 126, 234, 0.2)',
                borderColor: 'rgba(102, 126, 234, 1)',
                borderWidth: 2,
                pointBackgroundColor: colors,
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            scales: {
                r: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        stepSize: 20,
                        callback: function(value) {
                            return value + '%';
                        }
                    },
                    grid: {
                        color: 'rgba(0, 0, 0, 0.1)'
                    },
                    angleLines: {
                        color: 'rgba(0, 0, 0, 0.1)'
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.parsed.r + '%';
                        }
                    }
                }
            }
        }
    });
}

function displayTraitDetails(predictions) {
    const traitDetails = document.getElementById('traitDetails');
    traitDetails.innerHTML = '';
    
    const traitDescriptions = {
        'Openness': 'Creativity, curiosity, and openness to new experiences',
        'Conscientiousness': 'Organization, discipline, and goal-oriented behavior',
        'Extraversion': 'Sociability, energy, and preference for social interaction',
        'Agreeableness': 'Cooperation, trust, and concern for others',
        'Neuroticism': 'Emotional instability and tendency to experience negative emotions'
    };
    
    Object.entries(predictions).forEach(([trait, data]) => {
        const traitCard = document.createElement('div');
        traitCard.className = 'trait-card';
        
        traitCard.innerHTML = `
            <h4>${trait}</h4>
            <div class="trait-score">${data.percentage}%</div>
            <div class="trait-level">${data.level} Level</div>
            <p style="margin-top: 10px; color: #718096; font-size: 0.9rem;">
                ${traitDescriptions[trait]}
            </p>
        `;
        
        traitDetails.appendChild(traitCard);
    });
}

// Allow Enter key to trigger analysis
document.getElementById('textInput').addEventListener('keydown', function(event) {
    if (event.ctrlKey && event.key === 'Enter') {
        analyzePersonality();
    }
});

// Auto-resize textarea
document.getElementById('textInput').addEventListener('input', function() {
    this.style.height = 'auto';
    this.style.height = this.scrollHeight + 'px';
});