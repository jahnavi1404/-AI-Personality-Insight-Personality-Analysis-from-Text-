#!/usr/bin/env python3
"""
Test script to verify the personality prediction system works correctly
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Test using the app's model loading
from app import load_models, model, preprocessor

def test_prediction():
    """Test the prediction pipeline"""
    print("🧪 Testing AI Personality Prediction System")
    print("=" * 50)
    
    # Load models using app's method
    try:
        success = load_models()
        if not success:
            print("❌ Failed to load models")
            return False
        print("✅ Models loaded successfully")
    except Exception as e:
        print(f"❌ Error loading models: {e}")
        return False
    
    # Test texts
    test_texts = [
        "I love exploring new ideas and creative projects. Art and philosophy fascinate me deeply.",
        "I always plan my day carefully and stick to my schedule. Organization is crucial for success.",
        "I absolutely love meeting new people and being around others! Parties energize me so much."
    ]
    
    print("\n🔍 Testing predictions:")
    
    for i, text in enumerate(test_texts, 1):
        print(f"\n--- Test {i} ---")
        print(f"Text: {text[:60]}...")
        
        try:
            # Use the global model and preprocessor from app
            from app import model, preprocessor
            
            # Preprocess and predict
            X = preprocessor.transform_text([text])
            predictions = model.predict_single(X)
            
            # Display results
            print("Predictions:")
            for trait, data in predictions.items():
                print(f"  {trait}: {data['percentage']}% ({data['level']})")
            
            # Get interpretation
            interpretation = model.get_interpretation(predictions)
            print(f"Interpretation: {interpretation[:100]}...")
            
        except Exception as e:
            print(f"❌ Prediction failed: {e}")
            return False
    
    print("\n🎉 All tests passed! The system is working correctly.")
    return True

if __name__ == "__main__":
    success = test_prediction()
    if not success:
        exit(1)